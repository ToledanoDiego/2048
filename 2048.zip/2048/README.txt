This is the README file for the final project Solving "2048" using AI.

In this directory, you will find two directories and three files.

The first directory is: Report in which you can find the final report of this project.
The second dierectory is: SourceCode in which you can find the source code of the AI.
The first file is: 2048.jar which is the executable file of the AI.
The second file is: README.txt which is the file you are reading right now. 
The third file is: Demo.txt which is containing the link of the demo video of the AI were you can see the AI solving the puzzle using MonteCarloTreeSeach